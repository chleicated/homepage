"use client"

import  from "../nuxt.config"

export default function SyntheticV0PageForDeployment() {
  return < />
}