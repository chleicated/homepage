<template>
  <div id="betterstack">
    <iframe 
      src="https://status.chle.sh/badge?theme=dark" 
      scrolling="no" 
      width="250" 
      height="30" 
      frameborder="0"
    />
  </div>
</template>
